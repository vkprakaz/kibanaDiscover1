"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.capabilitiesProvider = void 0;

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
const capabilitiesProvider = () => ({
  discover: {
    show: true,
    createShortUrl: true,
    save: true,
    saveQuery: true
  }
});

exports.capabilitiesProvider = capabilitiesProvider;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcGFiaWxpdGllc19wcm92aWRlci50cyJdLCJuYW1lcyI6WyJjYXBhYmlsaXRpZXNQcm92aWRlciIsImRpc2NvdmVyIiwic2hvdyIsImNyZWF0ZVNob3J0VXJsIiwic2F2ZSIsInNhdmVRdWVyeSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sTUFBTUEsb0JBQW9CLEdBQUcsT0FBTztBQUN6Q0MsRUFBQUEsUUFBUSxFQUFFO0FBQ1JDLElBQUFBLElBQUksRUFBRSxJQURFO0FBRVJDLElBQUFBLGNBQWMsRUFBRSxJQUZSO0FBR1JDLElBQUFBLElBQUksRUFBRSxJQUhFO0FBSVJDLElBQUFBLFNBQVMsRUFBRTtBQUpIO0FBRCtCLENBQVAsQ0FBN0IiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IEVsYXN0aWNzZWFyY2ggQi5WLiBhbmQvb3IgbGljZW5zZWQgdG8gRWxhc3RpY3NlYXJjaCBCLlYuIHVuZGVyIG9uZVxuICogb3IgbW9yZSBjb250cmlidXRvciBsaWNlbnNlIGFncmVlbWVudHMuIExpY2Vuc2VkIHVuZGVyIHRoZSBFbGFzdGljIExpY2Vuc2VcbiAqIDIuMCBhbmQgdGhlIFNlcnZlciBTaWRlIFB1YmxpYyBMaWNlbnNlLCB2IDE7IHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0XG4gKiBpbiBjb21wbGlhbmNlIHdpdGgsIGF0IHlvdXIgZWxlY3Rpb24sIHRoZSBFbGFzdGljIExpY2Vuc2UgMi4wIG9yIHRoZSBTZXJ2ZXJcbiAqIFNpZGUgUHVibGljIExpY2Vuc2UsIHYgMS5cbiAqL1xuXG5leHBvcnQgY29uc3QgY2FwYWJpbGl0aWVzUHJvdmlkZXIgPSAoKSA9PiAoe1xuICBkaXNjb3Zlcjoge1xuICAgIHNob3c6IHRydWUsXG4gICAgY3JlYXRlU2hvcnRVcmw6IHRydWUsXG4gICAgc2F2ZTogdHJ1ZSxcbiAgICBzYXZlUXVlcnk6IHRydWUsXG4gIH0sXG59KTtcbiJdfQ==