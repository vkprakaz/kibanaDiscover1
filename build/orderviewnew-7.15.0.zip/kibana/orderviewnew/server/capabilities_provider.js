"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.capabilitiesProvider = void 0;

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
const capabilitiesProvider = () => ({
  orderview: {
    show: true,
    createShortUrl: true,
    save: true,
    saveQuery: true
  }
});

exports.capabilitiesProvider = capabilitiesProvider;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcGFiaWxpdGllc19wcm92aWRlci50cyJdLCJuYW1lcyI6WyJjYXBhYmlsaXRpZXNQcm92aWRlciIsIm9yZGVydmlldyIsInNob3ciLCJjcmVhdGVTaG9ydFVybCIsInNhdmUiLCJzYXZlUXVlcnkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVPLE1BQU1BLG9CQUFvQixHQUFHLE9BQU87QUFDekNDLEVBQUFBLFNBQVMsRUFBRTtBQUNUQyxJQUFBQSxJQUFJLEVBQUUsSUFERztBQUVUQyxJQUFBQSxjQUFjLEVBQUUsSUFGUDtBQUdUQyxJQUFBQSxJQUFJLEVBQUUsSUFIRztBQUlUQyxJQUFBQSxTQUFTLEVBQUU7QUFKRjtBQUQ4QixDQUFQLENBQTdCIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBFbGFzdGljc2VhcmNoIEIuVi4gYW5kL29yIGxpY2Vuc2VkIHRvIEVsYXN0aWNzZWFyY2ggQi5WLiB1bmRlciBvbmVcbiAqIG9yIG1vcmUgY29udHJpYnV0b3IgbGljZW5zZSBhZ3JlZW1lbnRzLiBMaWNlbnNlZCB1bmRlciB0aGUgRWxhc3RpYyBMaWNlbnNlXG4gKiAyLjAgYW5kIHRoZSBTZXJ2ZXIgU2lkZSBQdWJsaWMgTGljZW5zZSwgdiAxOyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdFxuICogaW4gY29tcGxpYW5jZSB3aXRoLCBhdCB5b3VyIGVsZWN0aW9uLCB0aGUgRWxhc3RpYyBMaWNlbnNlIDIuMCBvciB0aGUgU2VydmVyXG4gKiBTaWRlIFB1YmxpYyBMaWNlbnNlLCB2IDEuXG4gKi9cblxuZXhwb3J0IGNvbnN0IGNhcGFiaWxpdGllc1Byb3ZpZGVyID0gKCkgPT4gKHtcbiAgb3JkZXJ2aWV3OiB7XG4gICAgc2hvdzogdHJ1ZSxcbiAgICBjcmVhdGVTaG9ydFVybDogdHJ1ZSxcbiAgICBzYXZlOiB0cnVlLFxuICAgIHNhdmVRdWVyeTogdHJ1ZSxcbiAgfSxcbn0pO1xuIl19