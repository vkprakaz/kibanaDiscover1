"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.searchSavedObjectType = void 0;

var _search_migrations = require("./search_migrations");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
const searchSavedObjectType = {
  name: 'searchNew',
  hidden: false,
  namespaceType: 'single',
  management: {
    icon: 'discoverApp',
    defaultSearchField: 'title',
    importableAndExportable: true,

    getTitle(obj) {
      return obj.attributes.title;
    },

    getEditUrl(obj) {
      return `/management/kibana/objects/savedSearches/${encodeURIComponent(obj.id)}`;
    },

    getInAppUrl(obj) {
      return {
        path: `/app/discover#/view/${encodeURIComponent(obj.id)}`,
        uiCapabilitiesPath: 'discover.show'
      };
    }

  },
  mappings: {
    properties: {
      columns: {
        type: 'keyword',
        index: false,
        doc_values: false
      },
      description: {
        type: 'text'
      },
      hideChart: {
        type: 'boolean',
        index: false,
        doc_values: false
      },
      hits: {
        type: 'integer',
        index: false,
        doc_values: false
      },
      kibanaSavedObjectMeta: {
        properties: {
          searchSourceJSON: {
            type: 'text',
            index: false
          }
        }
      },
      sort: {
        type: 'keyword',
        index: false,
        doc_values: false
      },
      title: {
        type: 'text'
      },
      grid: {
        type: 'object',
        enabled: false
      },
      version: {
        type: 'integer'
      }
    }
  },
  migrations: _search_migrations.searchMigrations
};
exports.searchSavedObjectType = searchSavedObjectType;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC50cyJdLCJuYW1lcyI6WyJzZWFyY2hTYXZlZE9iamVjdFR5cGUiLCJuYW1lIiwiaGlkZGVuIiwibmFtZXNwYWNlVHlwZSIsIm1hbmFnZW1lbnQiLCJpY29uIiwiZGVmYXVsdFNlYXJjaEZpZWxkIiwiaW1wb3J0YWJsZUFuZEV4cG9ydGFibGUiLCJnZXRUaXRsZSIsIm9iaiIsImF0dHJpYnV0ZXMiLCJ0aXRsZSIsImdldEVkaXRVcmwiLCJlbmNvZGVVUklDb21wb25lbnQiLCJpZCIsImdldEluQXBwVXJsIiwicGF0aCIsInVpQ2FwYWJpbGl0aWVzUGF0aCIsIm1hcHBpbmdzIiwicHJvcGVydGllcyIsImNvbHVtbnMiLCJ0eXBlIiwiaW5kZXgiLCJkb2NfdmFsdWVzIiwiZGVzY3JpcHRpb24iLCJoaWRlQ2hhcnQiLCJoaXRzIiwia2liYW5hU2F2ZWRPYmplY3RNZXRhIiwic2VhcmNoU291cmNlSlNPTiIsInNvcnQiLCJncmlkIiwiZW5hYmxlZCIsInZlcnNpb24iLCJtaWdyYXRpb25zIiwic2VhcmNoTWlncmF0aW9ucyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQVNBOztBQVRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBS08sTUFBTUEscUJBQXVDLEdBQUc7QUFDckRDLEVBQUFBLElBQUksRUFBRSxXQUQrQztBQUVyREMsRUFBQUEsTUFBTSxFQUFFLEtBRjZDO0FBR3JEQyxFQUFBQSxhQUFhLEVBQUUsUUFIc0M7QUFJckRDLEVBQUFBLFVBQVUsRUFBRTtBQUNWQyxJQUFBQSxJQUFJLEVBQUUsYUFESTtBQUVWQyxJQUFBQSxrQkFBa0IsRUFBRSxPQUZWO0FBR1ZDLElBQUFBLHVCQUF1QixFQUFFLElBSGY7O0FBSVZDLElBQUFBLFFBQVEsQ0FBQ0MsR0FBRCxFQUFNO0FBQ1osYUFBT0EsR0FBRyxDQUFDQyxVQUFKLENBQWVDLEtBQXRCO0FBQ0QsS0FOUzs7QUFPVkMsSUFBQUEsVUFBVSxDQUFDSCxHQUFELEVBQU07QUFDZCxhQUFRLDRDQUEyQ0ksa0JBQWtCLENBQUNKLEdBQUcsQ0FBQ0ssRUFBTCxDQUFTLEVBQTlFO0FBQ0QsS0FUUzs7QUFVVkMsSUFBQUEsV0FBVyxDQUFDTixHQUFELEVBQU07QUFDZixhQUFPO0FBQ0xPLFFBQUFBLElBQUksRUFBRyx1QkFBc0JILGtCQUFrQixDQUFDSixHQUFHLENBQUNLLEVBQUwsQ0FBUyxFQURuRDtBQUVMRyxRQUFBQSxrQkFBa0IsRUFBRTtBQUZmLE9BQVA7QUFJRDs7QUFmUyxHQUp5QztBQXFCckRDLEVBQUFBLFFBQVEsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUU7QUFDVkMsTUFBQUEsT0FBTyxFQUFFO0FBQUVDLFFBQUFBLElBQUksRUFBRSxTQUFSO0FBQW1CQyxRQUFBQSxLQUFLLEVBQUUsS0FBMUI7QUFBaUNDLFFBQUFBLFVBQVUsRUFBRTtBQUE3QyxPQURDO0FBRVZDLE1BQUFBLFdBQVcsRUFBRTtBQUFFSCxRQUFBQSxJQUFJLEVBQUU7QUFBUixPQUZIO0FBR1ZJLE1BQUFBLFNBQVMsRUFBRTtBQUFFSixRQUFBQSxJQUFJLEVBQUUsU0FBUjtBQUFtQkMsUUFBQUEsS0FBSyxFQUFFLEtBQTFCO0FBQWlDQyxRQUFBQSxVQUFVLEVBQUU7QUFBN0MsT0FIRDtBQUlWRyxNQUFBQSxJQUFJLEVBQUU7QUFBRUwsUUFBQUEsSUFBSSxFQUFFLFNBQVI7QUFBbUJDLFFBQUFBLEtBQUssRUFBRSxLQUExQjtBQUFpQ0MsUUFBQUEsVUFBVSxFQUFFO0FBQTdDLE9BSkk7QUFLVkksTUFBQUEscUJBQXFCLEVBQUU7QUFDckJSLFFBQUFBLFVBQVUsRUFBRTtBQUNWUyxVQUFBQSxnQkFBZ0IsRUFBRTtBQUFFUCxZQUFBQSxJQUFJLEVBQUUsTUFBUjtBQUFnQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXZCO0FBRFI7QUFEUyxPQUxiO0FBVVZPLE1BQUFBLElBQUksRUFBRTtBQUFFUixRQUFBQSxJQUFJLEVBQUUsU0FBUjtBQUFtQkMsUUFBQUEsS0FBSyxFQUFFLEtBQTFCO0FBQWlDQyxRQUFBQSxVQUFVLEVBQUU7QUFBN0MsT0FWSTtBQVdWWixNQUFBQSxLQUFLLEVBQUU7QUFBRVUsUUFBQUEsSUFBSSxFQUFFO0FBQVIsT0FYRztBQVlWUyxNQUFBQSxJQUFJLEVBQUU7QUFBRVQsUUFBQUEsSUFBSSxFQUFFLFFBQVI7QUFBa0JVLFFBQUFBLE9BQU8sRUFBRTtBQUEzQixPQVpJO0FBYVZDLE1BQUFBLE9BQU8sRUFBRTtBQUFFWCxRQUFBQSxJQUFJLEVBQUU7QUFBUjtBQWJDO0FBREosR0FyQjJDO0FBc0NyRFksRUFBQUEsVUFBVSxFQUFFQztBQXRDeUMsQ0FBaEQiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IEVsYXN0aWNzZWFyY2ggQi5WLiBhbmQvb3IgbGljZW5zZWQgdG8gRWxhc3RpY3NlYXJjaCBCLlYuIHVuZGVyIG9uZVxuICogb3IgbW9yZSBjb250cmlidXRvciBsaWNlbnNlIGFncmVlbWVudHMuIExpY2Vuc2VkIHVuZGVyIHRoZSBFbGFzdGljIExpY2Vuc2VcbiAqIDIuMCBhbmQgdGhlIFNlcnZlciBTaWRlIFB1YmxpYyBMaWNlbnNlLCB2IDE7IHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0XG4gKiBpbiBjb21wbGlhbmNlIHdpdGgsIGF0IHlvdXIgZWxlY3Rpb24sIHRoZSBFbGFzdGljIExpY2Vuc2UgMi4wIG9yIHRoZSBTZXJ2ZXJcbiAqIFNpZGUgUHVibGljIExpY2Vuc2UsIHYgMS5cbiAqL1xuXG5pbXBvcnQgeyBTYXZlZE9iamVjdHNUeXBlIH0gZnJvbSAna2liYW5hL3NlcnZlcic7XG5pbXBvcnQgeyBzZWFyY2hNaWdyYXRpb25zIH0gZnJvbSAnLi9zZWFyY2hfbWlncmF0aW9ucyc7XG5cbmV4cG9ydCBjb25zdCBzZWFyY2hTYXZlZE9iamVjdFR5cGU6IFNhdmVkT2JqZWN0c1R5cGUgPSB7XG4gIG5hbWU6ICdzZWFyY2hOZXcnLFxuICBoaWRkZW46IGZhbHNlLFxuICBuYW1lc3BhY2VUeXBlOiAnc2luZ2xlJyxcbiAgbWFuYWdlbWVudDoge1xuICAgIGljb246ICdkaXNjb3ZlckFwcCcsXG4gICAgZGVmYXVsdFNlYXJjaEZpZWxkOiAndGl0bGUnLFxuICAgIGltcG9ydGFibGVBbmRFeHBvcnRhYmxlOiB0cnVlLFxuICAgIGdldFRpdGxlKG9iaikge1xuICAgICAgcmV0dXJuIG9iai5hdHRyaWJ1dGVzLnRpdGxlO1xuICAgIH0sXG4gICAgZ2V0RWRpdFVybChvYmopIHtcbiAgICAgIHJldHVybiBgL21hbmFnZW1lbnQva2liYW5hL29iamVjdHMvc2F2ZWRTZWFyY2hlcy8ke2VuY29kZVVSSUNvbXBvbmVudChvYmouaWQpfWA7XG4gICAgfSxcbiAgICBnZXRJbkFwcFVybChvYmopIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHBhdGg6IGAvYXBwL2Rpc2NvdmVyIy92aWV3LyR7ZW5jb2RlVVJJQ29tcG9uZW50KG9iai5pZCl9YCxcbiAgICAgICAgdWlDYXBhYmlsaXRpZXNQYXRoOiAnZGlzY292ZXIuc2hvdycsXG4gICAgICB9O1xuICAgIH0sXG4gIH0sXG4gIG1hcHBpbmdzOiB7XG4gICAgcHJvcGVydGllczoge1xuICAgICAgY29sdW1uczogeyB0eXBlOiAna2V5d29yZCcsIGluZGV4OiBmYWxzZSwgZG9jX3ZhbHVlczogZmFsc2UgfSxcbiAgICAgIGRlc2NyaXB0aW9uOiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgaGlkZUNoYXJ0OiB7IHR5cGU6ICdib29sZWFuJywgaW5kZXg6IGZhbHNlLCBkb2NfdmFsdWVzOiBmYWxzZSB9LFxuICAgICAgaGl0czogeyB0eXBlOiAnaW50ZWdlcicsIGluZGV4OiBmYWxzZSwgZG9jX3ZhbHVlczogZmFsc2UgfSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgc2VhcmNoU291cmNlSlNPTjogeyB0eXBlOiAndGV4dCcsIGluZGV4OiBmYWxzZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHNvcnQ6IHsgdHlwZTogJ2tleXdvcmQnLCBpbmRleDogZmFsc2UsIGRvY192YWx1ZXM6IGZhbHNlIH0sXG4gICAgICB0aXRsZTogeyB0eXBlOiAndGV4dCcgfSxcbiAgICAgIGdyaWQ6IHsgdHlwZTogJ29iamVjdCcsIGVuYWJsZWQ6IGZhbHNlIH0sXG4gICAgICB2ZXJzaW9uOiB7IHR5cGU6ICdpbnRlZ2VyJyB9LFxuICAgIH0sXG4gIH0sXG4gIG1pZ3JhdGlvbnM6IHNlYXJjaE1pZ3JhdGlvbnMsXG59O1xuIl19