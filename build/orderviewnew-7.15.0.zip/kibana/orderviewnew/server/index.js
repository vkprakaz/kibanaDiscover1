"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = void 0;

var _plugin = require("./plugin");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
const plugin = () => new _plugin.OrderviewServerPlugin();

exports.plugin = plugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsIk9yZGVydmlld1NlcnZlclBsdWdpbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQVFBOztBQVJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSU8sTUFBTUEsTUFBTSxHQUFHLE1BQU0sSUFBSUMsNkJBQUosRUFBckIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IEVsYXN0aWNzZWFyY2ggQi5WLiBhbmQvb3IgbGljZW5zZWQgdG8gRWxhc3RpY3NlYXJjaCBCLlYuIHVuZGVyIG9uZVxuICogb3IgbW9yZSBjb250cmlidXRvciBsaWNlbnNlIGFncmVlbWVudHMuIExpY2Vuc2VkIHVuZGVyIHRoZSBFbGFzdGljIExpY2Vuc2VcbiAqIDIuMCBhbmQgdGhlIFNlcnZlciBTaWRlIFB1YmxpYyBMaWNlbnNlLCB2IDE7IHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0XG4gKiBpbiBjb21wbGlhbmNlIHdpdGgsIGF0IHlvdXIgZWxlY3Rpb24sIHRoZSBFbGFzdGljIExpY2Vuc2UgMi4wIG9yIHRoZSBTZXJ2ZXJcbiAqIFNpZGUgUHVibGljIExpY2Vuc2UsIHYgMS5cbiAqL1xuXG5pbXBvcnQgeyBPcmRlcnZpZXdTZXJ2ZXJQbHVnaW4gfSBmcm9tICcuL3BsdWdpbic7XG5cbmV4cG9ydCBjb25zdCBwbHVnaW4gPSAoKSA9PiBuZXcgT3JkZXJ2aWV3U2VydmVyUGx1Z2luKCk7XG4iXX0=